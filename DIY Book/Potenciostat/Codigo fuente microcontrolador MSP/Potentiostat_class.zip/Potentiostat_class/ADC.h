/*
 * ADC.h
 *
 *  Created on: 17 mar. 2020
 *      Author: killan
 */

#ifndef ADC_H_
#define ADC_H_

namespace msp
{
#include <msp430.h>
#include <stdint.h>

class ADC
{
public:
    ADC();
    int init(uint8_t channels);
    unsigned int readSingleChannel(uint16_t channel);
};

} /* namespace msp */

#endif /* ADC_H_ */
