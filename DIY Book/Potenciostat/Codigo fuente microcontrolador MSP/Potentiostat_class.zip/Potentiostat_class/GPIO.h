/*
 * GPIO.h
 *
 *  Created on: Mar 10, 2020
 *      Author: killan
 */

#ifndef INCLUDE_GPIO_H_
#define INCLUDE_GPIO_H_
#include <stdint.h>
#include <msp430.h>
namespace msp
{

class GPIO
{
public:
    GPIO();
    static void setBit(volatile unsigned char *PortName, uint8_t pin_num)
    {
        *PortName |= pin_num;
    }

    static void clearBit(volatile unsigned char *PortName, uint8_t pin_num)
    {
        *PortName &= ~pin_num;
    }
};

} /* namespace msp */

#endif /* INCLUDE_GPIO_H_ */
