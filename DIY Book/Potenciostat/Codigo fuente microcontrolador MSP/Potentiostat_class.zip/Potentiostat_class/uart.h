/*
 * uart.h
 *
 *  Created on: Mar 10, 2020
 *      Author: killan
 */

#ifndef INCLUDE_UART_H_
#define INCLUDE_UART_H_
#include <msp430.h>
#include <GPIO.h>
#include <stdint.h>
#include <stddef.h>

namespace msp
{

class uart
{
public:
    uart(void);
    int init(uint32_t baud = 9600);
    int getchar(void);
    int putchar(int c);
    int puts(const char *str);
private:
    uint32_t baud;

};

struct baud_value
{
    uint32_t baud;
    uint16_t UCAxBR0;
    uint16_t UCAxBR1;
    uint16_t UCAxMCTL;
};
} /* namespace msp */

#endif /* INCLUDE_UART_H_ */
