/*
 * uart.cpp
 *
 *  Created on: Mar 10, 2020
 *      Author: killan
 */

#include <uart.h>

namespace msp
{
const struct baud_value baud_tbl[] = { { 9600, 0x82, 0x06, UCBRS_6 },
                                       { 115200, 138, 0, UCBRS_7 } };
#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))

uart::uart(void)
{
    // TODO Auto-generated constructor stub
    this->baud = 9600;
    /* UART pin configuration */
    GPIO::setBit(&P1SEL, (BIT1 + BIT2));
    GPIO::setBit(&P1SEL2, (BIT1 + BIT2));
}

int uart::init(uint32_t baud)
{

    int status = -1;

    this->baud = baud;

    /* USCI should be in reset before configuring - only configure once */
    if (UCA0CTL1 & UCSWRST)
    {
        size_t i;

        /* Set clock source to SMCLK */
        UCA0CTL1 |= UCSSEL_2;
        /* Find the settings from the baud rate table */
        for (i = 0; i < ARRAY_SIZE(baud_tbl); i++)
        {
            if (baud_tbl[i].baud == this->baud)
            {
                break;
            }
        }

        if (i < ARRAY_SIZE(baud_tbl))
        {
            /* Set the baud rate */
            UCA0BR0 = baud_tbl[i].UCAxBR0;
            UCA0BR1 = baud_tbl[i].UCAxBR1;
            UCA0MCTL = baud_tbl[i].UCAxMCTL;

            /* Enable the USCI peripheral (take it out of reset) */
            UCA0CTL1 &= ~UCSWRST;
            status = 0;
        }
    }

    return status;
}

int uart::getchar(void)
{
    int chr = -1;
    if (IFG2 & UCA0RXIFG)
    {
        chr = UCA0RXBUF;
    }
    return chr;
}
int uart::putchar(int c)
{
    /* Wait for the transmit buffer to be ready */
    while (!(IFG2 & UCA0TXIFG))
        ;

    /* Transmit data */
    UCA0TXBUF = (char) c;

    return 0;
}
int uart::puts(const char *str)
{
    int status = -1;

    if (str != NULL)
    {
        status = 0;

        while (*str != '\0')
        {
            /* Wait for the transmit buffer to be ready */
            while (!(IFG2 & UCA0TXIFG))
                ;

            /* Transmit data */
            UCA0TXBUF = *str;

            /* If there is a line-feed, add a carriage return */
            if (*str == '\n')
            {
                /* Wait for the transmit buffer to be ready */
                while (!(IFG2 & UCA0TXIFG))
                    ;
                UCA0TXBUF = '\r';
            }

            str++;
        }
    }

    return status;
}

} /* namespace msp */
