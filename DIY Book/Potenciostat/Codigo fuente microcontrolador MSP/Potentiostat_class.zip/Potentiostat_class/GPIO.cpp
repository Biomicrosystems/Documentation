/*
 * GPIO.cpp
 *
 *  Created on: Mar 10, 2020
 *      Author: killan
 */

#include <GPIO.h>

namespace msp
{

GPIO::GPIO()
{
    // TODO Auto-generated constructor stub
}


} /* namespace msp */
