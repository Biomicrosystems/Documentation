/*
 * Technique.cpp
 *
 *  Created on: Mar 11, 2020
 *      Author: killan
 */

#include <Technique.h>

bool Technique::isRunning()
{
    return active;
}
