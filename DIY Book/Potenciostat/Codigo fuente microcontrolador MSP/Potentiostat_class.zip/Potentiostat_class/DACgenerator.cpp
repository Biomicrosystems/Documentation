/*
 * DACgenerator.cpp
 *
 *  Created on: Mar 11, 2020
 *      Author: killan
 */

#include <DACgenerator.h>

DAC_generator::DAC_generator()
{
    // TODO Auto-generated constructor stub

}

