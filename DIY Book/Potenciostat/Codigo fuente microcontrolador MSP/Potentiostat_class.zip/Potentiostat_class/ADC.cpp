/*
 * ADC.cpp
 *
 *  Created on: 17 mar. 2020
 *      Author: killan
 */

#include <ADC.h>

namespace msp
{

ADC::ADC()
{
    // TODO Auto-generated constructor stub

}

int ADC::init(uint8_t channels)
{
    /* Disable ADC for config */
    ADC10CTL0 &= ~ENC;
    /* Vcc & Vss as reference, enable ADC interupt, 8 � ADC10CLKs*/
    ADC10CTL0 = SREF_0 + ADC10SHT_2 + ADC10ON + ADC10IE;
    /* ChannelX ADC10CLK/4 */
    ADC10CTL1 = INCH_0 + ADC10DIV_3;
    /* Enable ADC Selected channels */
    ADC10AE0 |= channels;
    /* Enable ADC for use */
    ADC10CTL0 |= ENC;
    return 0;
}

unsigned int ADC::readSingleChannel(uint16_t channel)
{
    /* Disable ADC10 */
    ADC10CTL0 &= ~ENC;
    /* set conversion channel */
    switch (channel)
    {
    case 0:
        ADC10CTL1 = INCH_0 + ADC10DIV_3;
        break;
    case 3:
        ADC10CTL1 = INCH_3 + ADC10DIV_3;
        break;
    default:
        break;
    }
    /* Enable ADC for use */
    /* Sampling and conversion start */
    ADC10CTL0 |= ENC + ADC10SC;
    /* Low Power Mode 0 with interrupts enabled */
    __bis_SR_register(CPUOFF + GIE);
    ADC10CTL0 &= ~ADC10IFG; // deletes the ADC-InterruptFlag for the next conversation
    return ADC10MEM;
}
/*
// ADC10 interrupt service routine
#pragma vector = ADC10_VECTOR
__interrupt void ADC10_ISR(void)
{
    __bic_SR_register_on_exit(CPUOFF);        // Return to active mode }
}
*/
} /* namespace msp */
